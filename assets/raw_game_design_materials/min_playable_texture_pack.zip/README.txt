Minimal playable texture pack

Contents:
- 3 neutral tiles
- 4 product tiles: postgres, nginx, docker, k8s
- 2 DDoS-Guard themed tiles
- 1 audit module tile
- 2 transparent damage overlays
- atlas_4x3.png for quick import
- demo_grid.png preview with overlays applied

Recommended usage:
- Base gameplay pool: neutral_01, neutral_dark, neutral_signal
- Product/special blocks: postgres, nginx, docker, k8s, ddg_core, ddg_shield, audit_module
- Damage states: alpha-overlay damage_overlay_1 and damage_overlay_2 on top of any base tile
