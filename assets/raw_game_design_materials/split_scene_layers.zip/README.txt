Split scene layers from uploaded concept image

Original size: 1024x1536

foreground_curb.png
- cropped size: 1024x148
- original bbox: (0, 496, 1024, 644)

background_facade.png
- cropped size: 591x736
- original bbox: (216, 680, 807, 1416)

Also included:
- foreground_curb_fullcanvas.png
- background_facade_fullcanvas.png

Recommended use:
- Use the cropped PNGs for compact asset import.
- Use the full-canvas PNGs if you want to place both layers without manual offset reconstruction.
